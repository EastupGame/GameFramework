#include "gamebase.h"
HANDLE consoleBuffer[2];	//��������
INT index;
void ConsoleInit()
{
	//ȭ�� ���� 2�� �����
	consoleBuffer[0]=CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE,
		NULL, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
	consoleBuffer[1]=CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE,
		NULL, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
	//ȭ�� Ŀ�� �����
	CONSOLE_CURSOR_INFO cci;
	cci.dwSize = 1;
	cci.bVisible = FALSE;
	SetConsoleCursorInfo(consoleBuffer[0], &cci);
	SetConsoleCursorInfo(consoleBuffer[1], &cci);
}

void ConsoleRelease()
{
	CloseHandle(consoleBuffer[0]);
	CloseHandle(consoleBuffer[1]);
}

void ConsoleClear()
{
	COORD coord = { 0,0 };
	DWORD dw;
	FillConsoleOutputCharacter(consoleBuffer[index], ' ',
		80 * 25, coord, &dw);
}

void ConsoleFlipping()
{
	SetConsoleActiveScreenBuffer(consoleBuffer[index]);
	index = !index;	//0�� 1�� �ٲ۴�.
}

void CosolePrint(int x, int y, char * string)
{
	DWORD dw;
	COORD CursorPosition = { x, y };
	SetConsoleCursorPosition(
		consoleBuffer[index],
		CursorPosition
	);
	WriteFile(consoleBuffer[index], string, strlen(string),
		&dw, NULL);
}

