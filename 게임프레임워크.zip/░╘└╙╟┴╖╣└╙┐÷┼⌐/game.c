#include "gamebase.h"

void Init()
{
}

void Update()
{
}

void Render()
{
	//gotoxy(10, 2);	printf("���ڿ�");
	CosolePrint(10, 2, "���ڿ�");
}

void Release()
{
}
